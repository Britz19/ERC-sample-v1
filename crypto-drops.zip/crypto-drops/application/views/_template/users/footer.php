<div class="footer">
	<div class="container-fluid">
		<div class="row justify-content-center">
			<div class="col-lg-3">
				
				<!-- Affiliated with -->
				<p>
					<strong>
						Affiliated with :
					</strong>
				</p>
				<p>
					<a href="#">
						<img src="<?=base_url()?>assets/img/logo.png" width="300">
					</a>
				</p>
				<br>
				<!-- Follow Us -->
				<p>
					<strong>
						Follow Us : 
					</strong>
				</p>
				<h3>
					<a class="slinks" href="">
						<i class="fab fa-facebook"></i>
					</a>
					<a class="slinks" href="">
						<i class="fab fa-twitter"></i>
					</a>
					<a class="slinks" href="">
						<i class="fab fa-github"></i>
					</a>
					<a class="slinks" href="">
						<i class="fab fa-discord"></i>
					</a>
					<a class="slinks" href="">
						<i class="fab fa-bitcoin"></i>
					</a>
					<a class="slinks" href="">
						<i class="fab fa-telegram"></i>
					</a>
				</h3>
				<br>
				<!-- NEWSLETTER -->
				<p>
					<strong>
						Get Latest Updates :
					</strong>
				</p>
				<form method="POST" action="#">
					<div class="inp-email">
						<input type="email" name="" placeholder="Email Address">
					</div>
					<div class="inp-submit">
						<input type="submit" name="" value="SUBSCRIBE">
					</div>
				</form>
			</div>
			<div class="col-lg-3">
				
			</div>
			<div class="col-lg-3">
				
			</div>
			<div class="col-lg-2">
				<ul>
					<li style="list-style: none; padding: 3px;">
						<a class="btt-top" href="<?=base_url()?>Updates">
								<i class="fas fa-angle-right"></i> Updates
						</a>
					</li>
					<li style="list-style: none; padding: 3px;">
						<a class="btt-top" href="<?=base_url()?>Airdrops">
								<i class="fas fa-angle-right"></i> Airdrops
						</a>
					</li>
					<li style="list-style: none; padding: 3px;">
						<a class="btt-top" href="<?=base_url()?>Upcoming">
								<i class="fas fa-angle-right"></i> Upcoming
						</a>
					</li>
					<li style="list-style: none; padding: 3px;">
						<a class="btt-top" href="<?=base_url()?>Contact_Us">
								<i class="fas fa-angle-right"></i> Contact
						</a>
					</li>
					<li style="list-style: none; padding: 3px;">
						<a class="btt-top" href="<?=base_url()?>FAQS">
								<i class="fas fa-angle-right"></i> FAQ
						</a>
					</li>
					<li style="list-style: none; padding: 3px;">
						<a class="btt-top" id="btt-scrolltop" href="">
								<i class="fas fa-angle-right"></i> Back to top
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</div>