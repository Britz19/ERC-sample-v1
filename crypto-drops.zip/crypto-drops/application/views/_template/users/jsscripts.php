<!-- Scripts -->
<script type="text/javascript" src="<?=base_url()?>assets/js/jquery-3.3.1.slim.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/popper.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/navigation.js"></script>
<script type="text/javascript">
	$(document).ready(function () {
	    $('#btt-scrolltop').click(function () {
	        $("html, body").animate({
	            scrollTop: 0
	        }, 600);
	        return false;
	    });
	});	
</script>

    