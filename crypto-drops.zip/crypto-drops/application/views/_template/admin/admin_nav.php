<nav id="sidebar">
            <div class="sidebar-header">
                <h3> CRYPTODROP </h3>
            </div>
            <ul class="list-unstyled components">
                <p>
                    
                </p>
                <li class="nav-item">
                    <a href="<?=base_url()?>Dashboard"> DASHBOARD </a>
                </li>
                <li class="nav-item">
                    <a href="<?=base_url()?>AAirdrops"> AIRDROPS </a>
                </li>
                <li>
                    <a href="#"> REQUESTS </a>
                </li>
                <li>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> OPTION </a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li class="nav-item">
                            <a href="<?=base_url()?>Platforms"> PLATFORMS </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=base_url()?>Requirements"> REQUIREMENTS </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="<?=base_url()?>Updates" target="_blank"> VISIT WEBSITE </a>
                </li>
            </ul>
        </nav>