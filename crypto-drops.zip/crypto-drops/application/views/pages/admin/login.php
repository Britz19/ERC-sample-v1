<div class="wrapper">
	<div class="container-fluid">
		<div class="row mb-5 p-5 header">
			<div class="col-sm-12 col-md-12 col-lg-2 mb-5">
				<div class="login-header">
					<img src="<?=base_url()?>assets/img/cd-logo.png">
				</div>
			</div>
			<div class="col-sm-12 col-md-12 col-lg-4 col-xl-3 ml-auto">
				<div class="form-container">
					<form class="form-controller" method="<?=base_url()?>Dashboard">
						<div class="input-container">
							<input type="text" name="" placeholder="Email">
						</div>
						<div class="input-container">
							<input type="password" name="" placeholder="Password">
						</div>
						<div class="input-container-s">
							<input type="submit" name="" value="LOGIN">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer">
	<div class="container-fluid">
		<div class="p-5">
			<p>&copy; 2019<p>
		</div>
	</div>
</div>